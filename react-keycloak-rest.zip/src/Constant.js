const REALMS = "IAM_BFI_TEST";

const HOST = "https://keycloak-nonprod-private.bfi.co.id";

const KEYCLOAK = {
    LOGIN_URL:`${HOST}/auth/realms/${REALMS}/protocol/openid-connect/token`,
    GET_MENU:`${HOST}/auth/realms/${REALMS}/authz/protection/resource_set`,
    GET_RESOURCE_ACCESS:`${HOST}/auth/realms/${REALMS}/protocol/openid-connect/token`,
}

export {KEYCLOAK};