import logo from './logo.svg';
import './App.css';
// import {login} from "./service/Keycloak";
import React, {useState} from "react";
import {KEYCLOAK} from "./Constant";
import keycloak_resource from "./config/keycoak-resource.json"

function App() {
    const [state, setState] = useState({
        access_token: '',
        list_menu: [],
        use_force_update: 1,
    })

    const login = () => {
        const qs = require('query-string');
        const reqBody = qs.stringify({
            client_id: 'new-insurance',
            client_secret: 'H0DrbFOyVsEPeXuInvM5RyBQaeq7Ci34',
            grant_type: 'password',
            username: 'pandumalik',
            password: 'password',
        });

        return fetch(KEYCLOAK.LOGIN_URL, {
            method: 'POST',
            headers: {
                'Content-type': 'application/x-www-form-urlencoded',
            },
            body: reqBody
        }).then(response => {
            response.json().then(result => {
                setState({
                    ...state,
                    access_token: result.access_token
                })
            })
        });
    }

    const forceUpdate = () => {
        setState({
            ...state,
            use_force_update: state.use_force_update + 1
        })
    }

    const getMenuList = () => {
        const menu_list = [];
        return fetch(KEYCLOAK.GET_MENU, {
            method: 'GET',
            headers: {
                'Authorization': `bearer ${state.access_token}`,
                'Access-Control-Allow-Origin': '*'
            },
        }).then(response => {
            response.json().then(result => {
                result.forEach(resource_id => {
                    const menu = getMenu(resource_id);
                    menu_list.push(menu)
                })
                return menu_list;
            })
        });
    }

    const getMenu = (resource_id) => {
        let response_menu = {};
        fetch(`${KEYCLOAK.GET_MENU}/${resource_id}`, {
            method: 'GET',
            headers: {
                'Authorization': `bearer ${state.access_token}`,
                'Access-Control-Allow-Origin': '*'
            },
        }).then(response => {
            response.json().then(result => {
                const menu_name = result.name;
                response_menu = {menu_name: getResourceDetail(menu_name)}
            })
        });
        return response_menu;
    }

    const getResourceDetail = (resource_name) => {
        let is_allowed = false;
        const qs = require('query-string');
        const reqBody = qs.stringify({
            grant_type: 'urn:ietf:params:oauth:grant-type:uma-ticket',
            audience: 'new-insurance',
            permission: resource_name,
            response_mode: 'decision',
        });
        fetch(`${KEYCLOAK.GET_RESOURCE_ACCESS}`, {
            method: 'POST',
            headers: {
                'Authorization': `bearer ${state.access_token}`,
                'Access-Control-Allow-Origin': '*'
            },
            body: reqBody
        }).then(response => {
            response.json().then(result => {
                is_allowed = result.result;
            })
        });
        return is_allowed;
    }

    async function getMenuAllowed() {
        const qs = require('query-string');
        const list_resource = keycloak_resource.resources
        let list_allowed_resource = [];
        list_resource.forEach((resource) => {
            const reqBody = qs.stringify({
                grant_type: 'urn:ietf:params:oauth:grant-type:uma-ticket',
                audience: 'new-insurance',
                permission: resource.name,
                response_mode: 'decision'
            });

            fetch(`${KEYCLOAK.GET_RESOURCE_ACCESS}`, {
                method: 'POST',
                headers: {
                    'Content-type': 'application/x-www-form-urlencoded',
                    'Authorization': `bearer ${state.access_token}`,
                },
                body: reqBody
            }).then(response => {
                response.json().then(result => {
                    if (result.result) {
                        list_allowed_resource.push(resource.name)
                        setState({
                            ...state,
                            list_menu: [...list_allowed_resource]
                        })
                    }
                })
            });
        })
    }

    return (
        <div className="App">
            <header className="App-header">
                <img src={logo} className="App-logo" alt="logo"/>
                <p>

                </p>
                <div>[TOKEN HERE]</div>
                <div>{state.access_token.substr(0, 30).concat('...')}</div>
                <div>===============================================================</div>
                <div>[ALLOWED MENU]</div>
                <div style={{display: 'flex', flexDirection: 'row'}}>
                    {state.list_menu.map(resource => {
                        return (
                            <div>[{resource.toString()}] </div>
                        )
                    })}
                </div>
                <button onClick={() => login()}>CLICK ME FOR LOGIN</button>
                <button onClick={() => getMenuAllowed()}>GET MENU ALLOWED HERE</button>
                {/*<button onClick={() => forceUpdate()}>VIEW MENU</button>*/}
            </header>
        </div>
    );
}

export default App;
